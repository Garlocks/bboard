#include <iostream>
#include <string>
#include "BBoard.h"
using namespace std;

int main() {
    string userfile;
    string datafile;
    
    cout << "User file?" << endl;
    cin >> userfile;
    cout << endl;
//cout << "worked" << endl;
    cout << "Message file?" << endl;
    cin >> datafile;
    cout << endl;
//cout << "worked1" << endl;
    BBoard bb("CS12 Bulletin Board");
   //cout << "worked2" << endl;
    if (!bb.loadUsers(userfile))
    {
        cout << "ERROR: Cannot load users from " << userfile << endl;
        return 1;
    }
   //cout << "worked3" << endl;
    if (!bb.loadMessages(datafile))
    {
        cout << "ERROR: Cannot load messages from " << datafile << endl;
        return 1;
    }
   //:cout << "worked4" << endl;
    bb.login();
    bb.run();
//cout << "worked" << endl;
    if (!bb.saveMessages(datafile))
    {
        cout << "ERROR: Cannot save messages to " << datafile << endl;
        return 1;
    }
//cout << "worked5" << endl;
    return 0;
} 
