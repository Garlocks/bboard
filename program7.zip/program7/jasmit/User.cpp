#include <iostream>
#include "User.h"

using namespace std;





User :: User()
{
    username = "";
    password = "";
    return;
}

User :: User(const string& uname, const string& pass)
{
    username = uname;
    password = pass;
    return;
}

string User :: getUsername() const
{
    return username;
}

bool User :: check(const string &uname, const string &pass) const
{
    if ( username == "" || password == "" )
    {
        return false;
    }
    
    if ( username == uname && password == pass )
    {
        return true;
    }
    
    return false;
}

bool User :: setPassword(const string &oldpass, const string &newpass)
{
    if ( username.size() < 1 )
    {
        return false;
    }
    
    else if ( oldpass == password )
    {
        password = newpass;
        return true;
    }
    
    else
    {
        return false;
    }
    
}