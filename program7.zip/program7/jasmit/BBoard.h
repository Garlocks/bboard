#ifndef BBOARD_H
#define BBOARD_H

#include<iostream>
#include<fstream>
#include<vector>
#include "User.h"
#include "Message.h"

using namespace std;

class BBoard{
    
    private:
        string title;
        vector<User> userList;
        const User *currentUser;
        vector<Message *> messageList;
        void display() const;
		void addTopic();
		void addReply();
		void addUser(const string &name, const string &pass);
	    //int strToInt(string s);
		const User * getUser(const string &name, const string &pw) const;
        
        
    public:
        BBoard();
        BBoard(const string &ttl);
		~BBoard();
        bool loadUsers(const string &userfile);
		bool loadMessages(const string& datafile);
		bool saveMessages(const string& datafile);
        void login();
        void run();
        
};
#endif