#include <iostream>
#include <sstream>
#include "Message.h"
#include "Topic.h"

using namespace std;

	Topic :: Topic(){}
	Topic :: Topic(const string &athr, const string &sbjct, const string &body, unsigned id) : Message(athr, sbjct, body, id){}
	bool Topic :: isReply() const{
    	return false;
	}
	string Topic::toFormattedString() const{
		/* toFormattedString writes the contents of the Topic to a 
      * string in the following format:

        <begin_topic>
        :id: 4
        :subject: single line
        :from: author
        :children: 5 6 [this line should not be printed if there are no children.]
        :body: multiple lines - line 1
        line 2
        line 3
        <end>

      * line starting with :children: has the ID's of all children (See file specs. 
      * for details)
      * This function should not assume the last character in body is a newline.
      * In other words, this function must manually add a newline after the last    
      * line of the body (line 3 in this example).
      * Also, the last character in the string must be a newline.
      */
		stringstream file;
		file << "<begin_topic>" << endl;
		file << ":id: " << id << endl;
		file << ":subject: " << subject << endl;
		file << ":from: " << author << endl;
		if(childList.size() != 0){
			file << ":children: ";
			for(unsigned i = 0; i < childList.size(); i++){
				file << childList.at(i)->getID();
				if(i != childList.size() - 1){
					file << " ";
				}
			}
			file << endl;
		}
		file << ":body: " << body << endl;
		file << "<end>" << endl;
		return file.str();
	}