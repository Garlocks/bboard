#include "BBoard.h"
#include "Message.h"
#include "Reply.h"
#include "Topic.h"
#include "User.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <vector>

using namespace std;

BBoard::BBoard() 
{
    title = "";
    userList.clear();
    currentUser = 0;
    messageList.clear();
}

BBoard::BBoard(const string &ttl) 
{
    title = ttl;
    userList.clear();
    currentUser = 0;
    messageList.clear();
}

BBoard::~BBoard() {
    for(unsigned i = 0; i < messageList.size(); i++) 
    {
        if(messageList.at(i) != 0)
        {
            delete messageList.at(i);
        }
    }
}

bool BBoard::loadUsers(const string &userfile) 
{
    ifstream file;
    string user;
    string pass;
    
    file.open(userfile.c_str());
    
    if(!file.is_open())
    {
        cout << "Error opening file." << endl;
        return false;
    }
    
    file >> user;
    
    while(user != "end") 
    {
        file >> pass;
        userList.push_back(User(user, pass));
        file >> user;
    }
    
    file.close();
    
    return true;
}

bool BBoard::loadMessages(const string &datafile)
{
    //cout << "opened" << endl;
    ifstream file;
    //ofstream file2;
    stringstream file3;
        
    file.open(datafile.c_str());
    
    if(!file.is_open()) 
    {
        cout << "Error opening file." << endl;
        return false;
    }
    
    unsigned msg;
    file >> msg;
    
    string input;
    string a;
    string sub;
    string b;
    string kid;
    string name;
    
    unsigned ID;
    unsigned kidID;

    vector<string> kids;
    
    Message* T = 0;
    Message* R = 0;
    
    while(!file.eof()){
        file >> input;
        
        if(input == "<begin_topic>") 
        {
            
            while(input != "<end>")
            {
                file >> input;
                
                if(input == ":id:") 
                {
                    file >> ID;
                }
                else if(input == ":subject:") 
                {
					file.get();
					getline(file, sub);
                }
                else if(input == ":from:") 
                {
                    file >> a;
                }
                else if(input == ":children:") 
                {
                    getline(file, input);
                    kids.push_back(input);
                }
                else if(input == ":body:") 
                {
                    b = "";
                    file.get();
                    
                    while(input != "<end>") 
                    {
                        getline(file, input);
                        
                        if(input != "<end>") 
                        {
                            b += input;
                        }
                        
                        file >> input;
                        
                        if(input != "<end>") 
                        {
                            b = b + ("\n" + input);
                        }
                    }
                    if(b.size() != 0 && b.at(b.size() - 1) == '\n') 
                    {
                        b.erase(b.size() - 1);
                    }
                    kid = "0";
                    kids.push_back(kid);
                }
            }
            T = new Topic(a, sub, b, ID);
            messageList.push_back(T);
        }
        else if(input == "<begin_reply>") 
        {
				
				while(input != "<end>")
				{
					file >> input;
					
					if(input == ":id:") 
					{
						file >> ID;
					}
					else if(input == ":subject:") 
					{
						file.get();
						file >> input;
						file.get();
						getline(file, sub);
					}
					else if(input == ":from:") 
					{
						file >> a;
					}
					else if(input == ":children:") 
					{
						getline(file, input);
						kids.push_back(input);
					}
					else if(input ==":body:") 
					{
						b = "";
						file.get();
						
						while(input != "<end>") 
						{
							getline(file, input);
							
							if(input != "<end>")
							{
								b += input;
							}
							
							file >> input;
							
							if(input != "<end>")
							{
								b += ("\n" + input);
							}
					    }
						
						if(b.size() != 0 && b.at(b.size() -1) == '\n') 
						{
							b.erase(b.size() - 1);
						}
						kid = "0";
						kids.push_back(kid);
					}
				}
			R = new Reply(a, sub, b, ID);
			messageList.push_back(R);
		}
	}
	
	for(unsigned i = 0; i < kids.size(); i++) 
	{
	    file3 << kids.at(i) << endl;
	}
    for(unsigned i = 0; i < msg; i++)
    {
        
        while(true)
        {
            file3 >> kidID;
            
            if(kidID == 0)
            {
                break;
            }
            messageList.at(i)->addChild(messageList.at(kidID - 1));
        }
    } 
    
    file.close();
    
    return true; 
} 


bool BBoard::saveMessages(const string &datafile) 
{
    
    ofstream file;
    file.open(datafile.c_str());
    file << messageList.size() << endl;
    
    for(unsigned i = 0; i < messageList.size(); i++) 
    {
        file << messageList.at(i)->toFormattedString();
    }   
    file.close(); 
    
    return true;    
}

void BBoard::login() 
{
    
    string user;
    string pass;
    
    cout << "Welcome to " << title << endl;
    
    while(currentUser == NULL)
    {
        cout << "Enter your username ('Q' or 'q' to quit): ";
        cin >> user;
        
        if(user == "Q" || user == "q")
        {
            cout << "Bye!" << endl;
            exit(1);
        }

        cout << "Enter your password: ";
        cin >> pass;
        
        currentUser = getUser(user, pass);
        
            if(currentUser == NULL)
            {
                cout << "Invalid Username or Password!" << endl;
            }
            cout << endl;
    }
    cout << "Welcome back " << currentUser->getUsername() << "!" << endl;
    cout << endl;
}

const User* BBoard::getUser(const string &name, const string &pw) const 
{
    for(unsigned i = 0; i < userList.size(); i++)
    {
        if(userList.at(i).check(name, pw))
        {
            
            return &userList.at(i);
        }
    }
    return 0;
}

void BBoard::run() 
{
    
    char userInput;
    
    do {
            cout << "Menu" << endl;
            cout << "- Display Messages ('D' or 'd')" << endl;
            cout << "- Add New Topic ('N' or 'n')" << endl;
            cout << "- Add Reply to a Topic ('R' or 'r')" << endl;
            cout << "- Quit ('Q' or 'q')" << endl;
            cout << "Choose an action: ";
            cin >> userInput;
            
            if(userInput == 'Q' || userInput == 'q') {
                break;
        }
        
        cin.ignore();
        cout << endl;
        
        if((userInput != 'D' && userInput != 'd') && (userInput != 'N' && userInput != 'n') && (userInput != 'Q' && userInput != 'q') && (userInput != 'R' && userInput != 'r')) 
        {
            cout << "\nInvalid action. Please try again.\n" << endl;
            
            continue; 
        }
        
        if(userInput == 'D' || userInput == 'd') 
        { 
            display();
            cout << endl;
        } 
        if(userInput == 'N' || userInput == 'n') 
        { 
            addTopic();
        } 
        if(userInput == 'R' || userInput == 'r') 
        {
            addReply();
        } 
        //cout << endl;
    }
    while(userInput != 'Q' && userInput != 'q');
    
    cout << "Bye!" << endl;
    
    return;
    
}

void BBoard::display() const 
{
    if(messageList.size() == 0) 
    {
        cout << "\nNothing to Display.\n";
        return;
    }
    for(unsigned i = 0; i < messageList.size(); i++)
    {
        if(!messageList.at(i)->isReply()) 
        {
            cout << "---------------------------------------------------------" << endl;
            
            messageList.at(i)->print(0);
        }
    }
    
    cout << "---------------------------------------------------------" << endl;
}

void BBoard::addTopic() 
{
    
    string temp = "";
    string subject = "";
    string body = "";
    string newB = "";
    
    cout << "Subject: ";
    getline(cin, subject);
    
    cout << "Body: ";
    
    while(true){
        getline(cin, body);
        
        if(body.empty())
        {
            break;
        }
        
        newB += (body + "\n");
    }
    
    Topic *newT = new Topic(currentUser->getUsername(),subject, newB, messageList.size() + 1);
    messageList.push_back(newT);
}

void BBoard::addReply() 
{
    
    bool correct = false;
    string b = "";
    string sub = "";
    string t = "";
    string b2 = "";
    
    int search;
    
    while(!correct)
    {
        cout << "Enter Message ID (-1 for Menu): ";
		cin >> search;
		
		if((search != -1 && search < 1) || search > static_cast<int>(messageList.size())) 
		{
		    cout << "Invalid Message ID!!" << endl << endl;
		}
		else 
		{
		    correct = true;
		}
    }
    
    if(search < 0){
        cout << endl;
        
        return;
    }
    
    cin.ignore();
    
    cout << "Enter body: ";
    
    while(true) 
    {
        getline(cin, b);
        
        if(b.empty()) 
        {
            break;
        }
        b2 += (b + "\n");
    }
    b2.append("\n");
    //b2 = b2.substr(0, b2.size() - 1);
    
    sub = messageList.at(search - 1)->getSubject();
    
    Reply *r = new Reply(currentUser->getUsername(), sub, b2, messageList.size() + 1);
    
    messageList.at(search - 1)->addChild(r);
    messageList.push_back(r);
}
