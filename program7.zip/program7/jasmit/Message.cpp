#include<iostream>
#include<sstream>
#include "Message.h"

using namespace std;

	Message::Message(): author(""), subject(""), body(""), id(0){}

	Message::Message(const string &athr, const string &sbjct, const string &body, unsigned id) : author(athr), subject(sbjct), body(body), id(id){}


	Message::~Message(){}

	void Message::print(unsigned indentation) const{
	 /* This function is responsible for printing the Message 
      * (whether Topic or Reply), and and all of the Message's 
      * "subtree" recursively:
      * After printing the Message with indentation n and appropriate 
      * format (see output details), it will invoke itself 
      * recursively on all of the Replies in its childList,
      * incrementing the indentation value at each new level.
      *
      * Note: Each indentation increment represents 2 spaces. e.g. if 
      * indentation == 1, the reply should be indented 2 spaces, if 
      * it's 2, indent by 4 spaces, etc.*/
		string empty = "";
		string full = body;
		for(unsigned i = 0; i < indentation; i++){
			empty += "  ";
		}
		if(isReply()){
			cout << endl;
		}
		cout << empty << "Message #" << getID() << ": " << getSubject() << endl;
		cout << empty << "from " << author << ": ";
		for(unsigned i = 0; i < (full.size() - 1); i++){
			if(full.at(i) == '\n') {
				full.insert(i + 1, empty);
			}
		}
		cout << full << endl;
		if(childList.size() != 0) {
			for(unsigned i = 0; i < childList.size(); i++) {
				childList.at(i)->print(indentation + 1);
			}
		}
	}

	const string& Message::getSubject() const{
		return subject;
	}

	unsigned Message::getID() const{
		return id;
	}

	void Message::addChild(Message *child){
		childList.push_back(child);
	}